package com.myfinance.api.apigestao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGestaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
